// SPIM S20 MIPS simulator.
// Definitions for the SPIM S20.
//
// Copyright (c) 1990-2010, James R. Larus.
// Changes for DOS and Windows versions by David A. Carley (dac@cs.wisc.edu)
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are met:
//
// Redistributions of source code must retain the above copyright notice,
// this list of conditions and the following disclaimer.
//
// Redistributions in binary form must reproduce the above copyright notice,
// this list of conditions and the following disclaimer in the documentation
// and/or other materials provided with the distribution.
//
// Neither the name of the James R. Larus nor the names of its contributors may
// be used to endorse or promote products derived from this software without
// specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
// AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
// LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
// CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
// SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
// INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
// CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
// POSSIBILITY OF SUCH DAMAGE.
//

#include "stdafx.h"
#include "util.h"
#include "regman.h"

LPTSTR MakeCRLFValid(LPCTSTR strBuf) {
  if (lstrlen(strBuf) == 0) return NULL;

  // Allocate our new buffer twice as large as the old
  LPTSTR strNew = new TCHAR[(size_t)lstrlen(strBuf) * 2 + 1];
  LPTSTR strRet = strNew;

  ASSERT(strBuf);

  while (*strBuf) {
    if (*strBuf == '\r') {
      COPYCHAR(strNew, strBuf);

      if (*strBuf == '\n')  // We had a CRLF.  Copy it.
        COPYCHAR(strNew, strBuf);
      else  // No LF.  Append one.
        APPENDCHAR(strNew, '\n');
    } else if (*strBuf == '\n') {
      APPENDCHAR(strNew, '\r');
      COPYCHAR(strNew, strBuf);

      // We had a LFCR.  Changed to CRLF.  Eat the CR.
      if (*strBuf == '\r') ++strBuf;
    } else
      COPYCHAR(strNew, strBuf);  // Normal
  }
  *strNew = NULL;

  return strRet;
}
