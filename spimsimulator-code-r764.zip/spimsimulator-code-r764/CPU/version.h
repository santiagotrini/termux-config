#define SPIM_VERSION "Version 9.1.24 of August 1, 2023 (final)"
